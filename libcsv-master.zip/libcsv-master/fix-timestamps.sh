#!/bin/sh

sleep 1
touch aclocal.m4
sleep 1
touch configure
touch Makefile.in
